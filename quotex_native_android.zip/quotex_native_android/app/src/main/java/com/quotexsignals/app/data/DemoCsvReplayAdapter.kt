package com.quotexsignals.app.data

import android.content.Context
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * DEMO / BACKTEST data source. Direct port of the original project's
 * adapters/csv_replay_adapter.py. Reads the bundled demo CSV from Android
 * assets and replays it against a simulated clock - no network, no
 * external process, works fully offline. This is the adapter selected by
 * default on first launch.
 *
 * CSV format (header required), identical to the original project:
 *   timestamp,open,high,low,close,volume
 *   2024-06-01T00:00:00Z,1.10500,1.10550,1.10480,1.10520,1200
 */
class DemoCsvReplayAdapter(
    private val context: Context,
    private val assetFileName: String,
    private val asset: String,
    private val market: String,
    private val speed: Double = 60.0
) : MarketDataAdapter {

    private var allCandles: List<Candle> = emptyList()
    private var startRealMs: Long = 0
    private var startSimMs: Long = 0
    private var connected = false
    private val lock = Object()

    private val isoFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    override fun connect() {
        val rows = mutableListOf<Candle>()
        context.assets.open(assetFileName).use { input ->
            BufferedReader(InputStreamReader(input)).use { reader ->
                reader.readLine() // skip header row
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    val parts = line!!.split(",")
                    if (parts.size < 5) continue
                    val ts = parseIsoUtc(parts[0].trim())
                    rows.add(
                        Candle(
                            timestampMs = ts,
                            open = parts[1].trim().toDouble(),
                            high = parts[2].trim().toDouble(),
                            low = parts[3].trim().toDouble(),
                            close = parts[4].trim().toDouble(),
                            volume = if (parts.size > 5) parts[5].trim().toDoubleOrNull() ?: 0.0 else 0.0,
                            asset = asset,
                            market = market
                        )
                    )
                }
            }
        }
        rows.sortBy { it.timestampMs }
        require(rows.isNotEmpty()) { "No candles found in asset $assetFileName" }
        synchronized(lock) {
            allCandles = rows
            startRealMs = System.currentTimeMillis()
            startSimMs = rows.first().timestampMs
            connected = true
        }
    }

    private fun parseIsoUtc(s: String): Long {
        val cleaned = if (s.endsWith("Z")) s.dropLast(1) else s
        return isoFormat.parse(cleaned)?.time
            ?: throw IllegalArgumentException("Bad timestamp: $s")
    }

    private fun simulatedNowMs(): Long {
        val elapsedRealMs = System.currentTimeMillis() - startRealMs
        val elapsedSimMs = (elapsedRealMs * speed).toLong()
        var simNow = startSimMs + elapsedSimMs
        // Loop the CSV forever so a demo session never runs dry.
        val lastClose = allCandles.last().closeTimeMs
        val totalSpanMs = lastClose - startSimMs
        if (totalSpanMs > 0) {
            val offset = (simNow - startSimMs).mod(totalSpanMs)
            simNow = startSimMs + offset
        }
        return simNow
    }

    private fun closedCandlesUpTo(nowMs: Long): List<Candle> =
        allCandles.filter { it.closeTimeMs <= nowMs }

    override fun isConnected(): Boolean = connected
    override fun getMarketType(): String = market
    override fun getAsset(): String = asset
    override fun nowMs(): Long = synchronized(lock) { simulatedNowMs() }

    override fun getClosedCandles(n: Int): List<Candle> = synchronized(lock) {
        val now = simulatedNowMs()
        val closed = closedCandlesUpTo(now)
        closed.takeLast(n)
    }

    override fun getCurrentPrice(): Double? = synchronized(lock) {
        if (allCandles.isEmpty()) return@synchronized null
        val now = simulatedNowMs()
        val closed = closedCandlesUpTo(now)
        val idx = closed.size
        if (idx < allCandles.size) {
            val forming = allCandles[idx]
            val span = (forming.closeTimeMs - forming.timestampMs).toDouble()
            val elapsed = (now - forming.timestampMs).coerceAtLeast(0).toDouble()
            val frac = if (span > 0) (elapsed / span).coerceAtMost(1.0) else 1.0
            forming.open + (forming.close - forming.open) * frac
        } else {
            closed.lastOrNull()?.close ?: allCandles.first().open
        }
    }

    override fun nextCandleCloseMs(): Long = synchronized(lock) {
        val now = simulatedNowMs()
        val closed = closedCandlesUpTo(now)
        val idx = closed.size
        if (idx < allCandles.size) allCandles[idx].closeTimeMs else allCandles.last().closeTimeMs
    }

    override fun getPriceAtOrAfter(tsMs: Long): Double? = synchronized(lock) {
        // Resolves using the actual historical candle close at/after tsMs -
        // i.e. the recorded close price for that 5-minute candle. Since the
        // simulated clock loops, tsMs (derived from a candle's own
        // closeTimeMs at signal time) is always within the original,
        // non-looped span, so this lookup is unambiguous.
        allCandles.firstOrNull { it.closeTimeMs >= tsMs }?.close
    }

    fun getSpeed(): Double = speed
}
