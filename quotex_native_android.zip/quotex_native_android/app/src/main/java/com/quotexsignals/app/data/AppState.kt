package com.quotexsignals.app.data

import androidx.lifecycle.MutableLiveData

data class DashboardState(
    val asset: String = "-",
    val market: String = "-",
    val mode: String = "DEMO",
    val connected: Boolean = false,
    val currentPrice: Double? = null,
    val trend: String? = null,
    val nextCandleCloseMs: Long? = null,
    val secondsRemaining: Int? = null,
    val latestSignal: SignalEngine.SignalResult? = null
)

/**
 * Process-wide observable state, updated by SignalMonitorService and
 * observed by the UI fragments. Equivalent role to the original project's
 * in-memory STATE dict + /api/state endpoint, minus the network hop -
 * everything runs in one process here.
 */
object AppState {
    val dashboard = MutableLiveData(DashboardState())

    /** Bumped whenever a new signal is recorded or a pending one resolves,
     *  so History/Statistics screens know to re-query the database. */
    val historyChanged = MutableLiveData(0L)

    fun notifyHistoryChanged() {
        historyChanged.postValue(System.currentTimeMillis())
    }
}
