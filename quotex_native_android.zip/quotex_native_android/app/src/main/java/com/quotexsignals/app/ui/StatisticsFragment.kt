package com.quotexsignals.app.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.quotexsignals.app.R
import com.quotexsignals.app.data.AppState
import com.quotexsignals.app.data.SignalDatabase

class StatisticsFragment : Fragment(R.layout.fragment_statistics) {

    private lateinit var db: SignalDatabase
    private val handler = Handler(Looper.getMainLooper())
    private var refreshRunnable: Runnable? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        db = SignalDatabase(requireContext())

        fun label(cardId: Int, text: String) {
            view.findViewById<View>(cardId).findViewById<TextView>(R.id.stat_label).text = text
        }
        label(R.id.card_total, "Total Signals")
        label(R.id.card_wins, "Wins")
        label(R.id.card_losses, "Losses")
        label(R.id.card_draws, "Draws")
        label(R.id.card_unavailable, "Unavailable")
        label(R.id.card_pending, "Pending")
        label(R.id.card_winrate, "Win Rate")
        label(R.id.card_today, "Today")

        refresh(view)
        AppState.historyChanged.observe(viewLifecycleOwner) { refresh(view) }

        // Also refresh periodically in case a signal resolves while this
        // screen is open without a new history event firing yet.
        refreshRunnable = object : Runnable {
            override fun run() {
                if (isAdded) {
                    refresh(view)
                    handler.postDelayed(this, 4000)
                }
            }
        }
        handler.postDelayed(refreshRunnable!!, 4000)
    }

    override fun onDestroyView() {
        refreshRunnable?.let { handler.removeCallbacks(it) }
        super.onDestroyView()
    }

    private fun refresh(view: View) {
        val stats = db.getStats()
        fun value(cardId: Int, text: String) {
            view.findViewById<View>(cardId).findViewById<TextView>(R.id.stat_value).text = text
        }
        value(R.id.card_total, stats.totalSignals.toString())
        value(R.id.card_wins, stats.wins.toString())
        value(R.id.card_losses, stats.losses.toString())
        value(R.id.card_draws, stats.draws.toString())
        value(R.id.card_unavailable, stats.unavailable.toString())
        value(R.id.card_pending, stats.pending.toString())
        value(R.id.card_winrate, "${stats.winRate}%")
        value(R.id.card_today, "${stats.todayTotal} (${stats.todayWins}W/${stats.todayLosses}L)")
    }
}
