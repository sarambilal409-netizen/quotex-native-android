package com.quotexsignals.app.data

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.TimeUnit

/**
 * LIVE data adapter for an AUTHORIZED websocket feed that YOU supply (e.g.
 * a licensed market-data vendor, or your own compliant middleware). Direct
 * port of the original project's adapters/websocket_adapter.py.
 *
 * This does NOT connect to Quotex directly and contains no logic to bypass
 * login, CAPTCHA, or anti-automation controls of any platform. It stays
 * unselected/unused until you enter a URL in Settings - LIVE mode never
 * claims a connection unless isConnected() genuinely reports one.
 *
 * Expected JSON message (one per websocket frame):
 *   {"type":"candle","market":"OTC","asset":"EURUSD_OTC",
 *    "timestamp":"2024-06-01T12:35:00Z","open":1.1052,"high":1.1056,
 *    "low":1.1049,"close":1.1054,"volume":1500,"closed":true}
 *   {"type":"price","market":"OTC","asset":"EURUSD_OTC","price":1.10538}
 *
 * If your provider uses a different schema, adjust handleMessage() below.
 */
class WebSocketAdapter(
    private val url: String,
    private val apiKey: String,
    private val asset: String,
    private val market: String,
    private val maxCandles: Int = 500
) : MarketDataAdapter {

    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .build()
    private var ws: WebSocket? = null
    private val candles = ConcurrentLinkedDeque<Candle>()
    @Volatile private var currentPrice: Double? = null
    @Volatile private var connected = false

    private val isoFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    override fun connect() {
        val requestBuilder = Request.Builder().url(url)
        if (apiKey.isNotBlank()) requestBuilder.addHeader("Authorization", "Bearer $apiKey")
        ws = client.newWebSocket(requestBuilder.build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                connected = true
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    handleMessage(JSONObject(text))
                } catch (_: Exception) {
                    // malformed message from provider - ignore, never guess
                }
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                connected = false
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                connected = false
            }
        })
    }

    private fun handleMessage(data: JSONObject) {
        val msgMarket = data.optString("market", "")
        val msgAsset = data.optString("asset", "")
        // Strict market/asset isolation - never mix feeds.
        if (msgMarket != market || msgAsset != asset) return

        when (data.optString("type")) {
            "candle" -> {
                if (!data.optBoolean("closed", false)) return
                val tsRaw = data.optString("timestamp", "")
                val cleaned = if (tsRaw.endsWith("Z")) tsRaw.dropLast(1) else tsRaw
                val ts = isoFormat.parse(cleaned)?.time ?: return
                val c = Candle(
                    timestampMs = ts,
                    open = data.optDouble("open"),
                    high = data.optDouble("high"),
                    low = data.optDouble("low"),
                    close = data.optDouble("close"),
                    volume = data.optDouble("volume", 0.0),
                    asset = asset,
                    market = market
                )
                if (candles.isEmpty() || candles.peekLast().timestampMs < c.timestampMs) {
                    candles.addLast(c)
                    while (candles.size > maxCandles) candles.removeFirst()
                }
            }
            "price" -> {
                currentPrice = data.optDouble("price")
            }
        }
    }

    override fun isConnected(): Boolean = connected
    override fun getMarketType(): String = market
    override fun getAsset(): String = asset
    override fun getCurrentPrice(): Double? = currentPrice
    override fun getClosedCandles(n: Int): List<Candle> = candles.toList().takeLast(n)
    override fun nowMs(): Long = System.currentTimeMillis()

    override fun nextCandleCloseMs(): Long {
        val last = candles.lastOrNull()?.closeTimeMs ?: return System.currentTimeMillis() + Candle.FIVE_MIN_MS
        var next = last
        val now = System.currentTimeMillis()
        while (next <= now) next += Candle.FIVE_MIN_MS
        return next
    }

    override fun getPriceAtOrAfter(tsMs: Long): Double? =
        candles.firstOrNull { it.closeTimeMs >= tsMs }?.close
        // null if not yet available/unreliable -> caller shows RESULT_UNAVAILABLE
}
