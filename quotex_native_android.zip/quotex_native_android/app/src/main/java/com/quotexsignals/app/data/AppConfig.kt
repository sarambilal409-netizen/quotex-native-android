package com.quotexsignals.app.data

import android.content.Context

/**
 * Persistent app configuration, backed by SharedPreferences. Kotlin
 * equivalent of the original project's config.yaml, editable from the
 * Settings screen. Defaults match the original project: DEMO mode, OTC
 * market, the bundled sample asset, 65% minimum confidence.
 */
class AppConfig(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("quotex_signal_assistant_config", Context.MODE_PRIVATE)

    companion object {
        const val ADAPTER_DEMO = "csv_replay"
        const val ADAPTER_WEBSOCKET = "websocket"
        const val ADAPTER_REST = "rest_polling"
    }

    var adapter: String
        get() = prefs.getString("adapter", ADAPTER_DEMO) ?: ADAPTER_DEMO
        set(v) = prefs.edit().putString("adapter", v).apply()

    var marketType: String
        get() = prefs.getString("market_type", "OTC") ?: "OTC"
        set(v) = prefs.edit().putString("market_type", v).apply()

    var asset: String
        get() = prefs.getString("asset", "EURUSD_OTC") ?: "EURUSD_OTC"
        set(v) = prefs.edit().putString("asset", v).apply()

    var minConfidence: Double
        get() = prefs.getFloat("min_confidence", 65.0f).toDouble()
        set(v) = prefs.edit().putFloat("min_confidence", v.toFloat()).apply()

    var demoSpeed: Double
        get() = prefs.getFloat("demo_speed", 60.0f).toDouble()
        set(v) = prefs.edit().putFloat("demo_speed", v.toFloat()).apply()

    var websocketUrl: String
        get() = prefs.getString("ws_url", "") ?: ""
        set(v) = prefs.edit().putString("ws_url", v).apply()

    var websocketApiKey: String
        get() = prefs.getString("ws_api_key", "") ?: ""
        set(v) = prefs.edit().putString("ws_api_key", v).apply()

    var restUrl: String
        get() = prefs.getString("rest_url", "") ?: ""
        set(v) = prefs.edit().putString("rest_url", v).apply()

    var restApiKey: String
        get() = prefs.getString("rest_api_key", "") ?: ""
        set(v) = prefs.edit().putString("rest_api_key", v).apply()

    /** Timeframe is fixed by design - not user-configurable. Exposed only
     *  for display in Settings. */
    val timeframeMinutes: Int get() = 5

    fun signalConfig(): SignalEngine.SignalConfig = SignalEngine.SignalConfig(
        minConfidence = minConfidence
    )

    val isDemoMode: Boolean get() = adapter == ADAPTER_DEMO
}
