package com.quotexsignals.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class SignalRow(
    val id: Long,
    val createdAtMs: Long,
    val asset: String,
    val market: String,
    val direction: String,
    val confidence: Double,
    val reasons: String,
    val candleTimeMs: Long,
    val entryPrice: Double,
    val entryTimeMs: Long,
    val expiryTimeMs: Long,
    val expiryPrice: Double?,
    val result: String   // PENDING / WIN / LOSS / DRAW / RESULT_UNAVAILABLE
)

data class Stats(
    val totalSignals: Int,
    val wins: Int,
    val losses: Int,
    val draws: Int,
    val unavailable: Int,
    val pending: Int,
    val winRate: Double,
    val todayTotal: Int,
    val todayWins: Int,
    val todayLosses: Int
)

/**
 * SQLite-backed, append-only signal log. Direct port of the original
 * project's core/result_tracker.py (there implemented over Python's
 * sqlite3; here implemented over Android's built-in SQLiteOpenHelper -
 * same schema and semantics, no extra dependency needed).
 *
 * finalizeResult() fires exactly once per row: rows already resolved are
 * left untouched, so a resolved result is never silently changed later.
 */
class SignalDatabase(context: Context) :
    SQLiteOpenHelper(context.applicationContext, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME = "signals.db"
        private const val DB_VERSION = 1
        private const val TABLE = "signals"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS $TABLE (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at INTEGER NOT NULL,
                asset TEXT NOT NULL,
                market TEXT NOT NULL,
                direction TEXT NOT NULL,
                confidence REAL NOT NULL,
                reasons TEXT NOT NULL,
                candle_time INTEGER NOT NULL,
                entry_price REAL NOT NULL,
                entry_time INTEGER NOT NULL,
                expiry_time INTEGER NOT NULL,
                expiry_price REAL,
                result TEXT NOT NULL DEFAULT 'PENDING'
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // No schema changes yet. Future migrations go here, guarded by
        // version number, so existing signal history is never dropped.
    }

    @Synchronized
    fun recordSignal(
        asset: String, market: String, direction: String, confidence: Double,
        reasons: List<String>, candleTimeMs: Long, entryPrice: Double,
        entryTimeMs: Long, expiryTimeMs: Long
    ): Long {
        val values = ContentValues().apply {
            put("created_at", System.currentTimeMillis())
            put("asset", asset)
            put("market", market)
            put("direction", direction)
            put("confidence", confidence)
            put("reasons", reasons.joinToString("\n"))
            put("candle_time", candleTimeMs)
            put("entry_price", entryPrice)
            put("entry_time", entryTimeMs)
            put("expiry_time", expiryTimeMs)
            put("result", "PENDING")
        }
        return writableDatabase.insert(TABLE, null, values)
    }

    @Synchronized
    fun getPending(): List<SignalRow> {
        val rows = mutableListOf<SignalRow>()
        readableDatabase.rawQuery("SELECT * FROM $TABLE WHERE result = 'PENDING'", null).use { c ->
            while (c.moveToNext()) rows.add(cursorToRow(c))
        }
        return rows
    }

    @Synchronized
    fun finalizeResult(signalId: Long, expiryPrice: Double?, direction: String) {
        val db = writableDatabase
        db.rawQuery(
            "SELECT entry_price FROM $TABLE WHERE id = ? AND result = 'PENDING'",
            arrayOf(signalId.toString())
        ).use { c ->
            if (!c.moveToFirst()) return  // already resolved or doesn't exist - never overwrite
            val entryPrice = c.getDouble(0)

            val result = when {
                expiryPrice == null -> "RESULT_UNAVAILABLE"
                expiryPrice == entryPrice -> "DRAW"
                direction == SignalEngine.CALL -> if (expiryPrice > entryPrice) "WIN" else "LOSS"
                else -> if (expiryPrice < entryPrice) "WIN" else "LOSS" // PUT
            }

            val values = ContentValues().apply {
                if (expiryPrice != null) put("expiry_price", expiryPrice) else putNull("expiry_price")
                put("result", result)
            }
            db.update(TABLE, values, "id = ? AND result = 'PENDING'", arrayOf(signalId.toString()))
        }
    }

    @Synchronized
    fun getHistory(limit: Int = 200): List<SignalRow> {
        val rows = mutableListOf<SignalRow>()
        readableDatabase.rawQuery(
            "SELECT * FROM $TABLE ORDER BY id DESC LIMIT ?", arrayOf(limit.toString())
        ).use { c ->
            while (c.moveToNext()) rows.add(cursorToRow(c))
        }
        return rows
    }

    @Synchronized
    fun getStats(): Stats {
        var total = 0; var wins = 0; var losses = 0; var draws = 0
        var unavailable = 0; var pending = 0
        readableDatabase.rawQuery("SELECT result, created_at FROM $TABLE", null).use { c ->
            val startOfDay = startOfTodayMs()
            var todayTotal = 0; var todayWins = 0; var todayLosses = 0
            while (c.moveToNext()) {
                total++
                val result = c.getString(0)
                val createdAt = c.getLong(1)
                when (result) {
                    "WIN" -> wins++
                    "LOSS" -> losses++
                    "DRAW" -> draws++
                    "RESULT_UNAVAILABLE" -> unavailable++
                    "PENDING" -> pending++
                }
                if (createdAt >= startOfDay) {
                    todayTotal++
                    if (result == "WIN") todayWins++
                    if (result == "LOSS") todayLosses++
                }
            }
            val decided = wins + losses
            val winRate = if (decided > 0) Math.round((wins.toDouble() / decided) * 1000) / 10.0 else 0.0
            return Stats(total, wins, losses, draws, unavailable, pending, winRate, todayTotal, todayWins, todayLosses)
        }
    }

    private fun startOfTodayMs(): Long {
        val cal = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    private fun cursorToRow(c: android.database.Cursor): SignalRow {
        fun idx(name: String) = c.getColumnIndexOrThrow(name)
        return SignalRow(
            id = c.getLong(idx("id")),
            createdAtMs = c.getLong(idx("created_at")),
            asset = c.getString(idx("asset")),
            market = c.getString(idx("market")),
            direction = c.getString(idx("direction")),
            confidence = c.getDouble(idx("confidence")),
            reasons = c.getString(idx("reasons")),
            candleTimeMs = c.getLong(idx("candle_time")),
            entryPrice = c.getDouble(idx("entry_price")),
            entryTimeMs = c.getLong(idx("entry_time")),
            expiryTimeMs = c.getLong(idx("expiry_time")),
            expiryPrice = if (c.isNull(idx("expiry_price"))) null else c.getDouble(idx("expiry_price")),
            result = c.getString(idx("result"))
        )
    }
}
