package com.quotexsignals.app.ui

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.quotexsignals.app.R
import com.quotexsignals.app.data.AppState
import com.quotexsignals.app.data.DashboardState
import com.quotexsignals.app.data.SignalEngine
import java.text.SimpleDateFormat
import java.util.Locale

class DashboardFragment : Fragment(R.layout.fragment_dashboard) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        fun cardLabel(cardId: Int) = view.findViewById<View>(cardId).findViewById<TextView>(R.id.stat_label)
        fun cardValue(cardId: Int) = view.findViewById<View>(cardId).findViewById<TextView>(R.id.stat_value)

        cardLabel(R.id.card_asset).text = "Asset"
        cardLabel(R.id.card_market).text = "Market"
        cardLabel(R.id.card_price).text = "Current Price"
        cardLabel(R.id.card_countdown).text = "Next Candle Close"
        cardLabel(R.id.card_trend).text = "Trend"
        cardLabel(R.id.card_connection).text = "Connection"

        val modeBadge = view.findViewById<TextView>(R.id.mode_badge)
        val signalDirection = view.findViewById<TextView>(R.id.signal_direction)
        val signalMeta = view.findViewById<TextView>(R.id.signal_meta)
        val signalReasons = view.findViewById<TextView>(R.id.signal_reasons)
        val dateFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

        AppState.dashboard.observe(viewLifecycleOwner) { state: DashboardState ->
            cardValue(R.id.card_asset).text = state.asset
            cardValue(R.id.card_market).text = state.market
            cardValue(R.id.card_price).text =
                state.currentPrice?.let { String.format(Locale.US, "%.5f", it) } ?: "-"
            cardValue(R.id.card_countdown).text = fmtCountdown(state.secondsRemaining)
            cardValue(R.id.card_trend).text = state.trend ?: "-"
            cardValue(R.id.card_connection).text = if (state.connected) "Connected" else "Disconnected"

            if (state.mode == "DEMO") {
                modeBadge.text = "DEMO MODE"
            } else {
                modeBadge.text = if (state.connected) "LIVE - CONNECTED" else "LIVE - NOT CONNECTED"
            }

            val sig = state.latestSignal
            if (sig == null) {
                signalDirection.text = "Waiting for first closed candle..."
                signalMeta.text = ""
                signalReasons.text = ""
            } else {
                signalDirection.text = sig.direction
                signalDirection.setTextColor(
                    ContextCompat.getColor(
                        requireContext(),
                        when (sig.direction) {
                            SignalEngine.CALL -> R.color.accent_green
                            SignalEngine.PUT -> R.color.accent_red
                            else -> R.color.text_secondary
                        }
                    )
                )
                val candleTimeStr = sig.candleTimeMs?.let { dateFmt.format(it) } ?: "-"
                signalMeta.text = "Asset: ${state.asset}  |  Market: ${state.market}\n" +
                    "Candle Close: $candleTimeStr  |  Expiry: 5 minutes\n" +
                    "Confidence: ${sig.confidence}%  |  Trend: ${sig.trend ?: "-"}  |  RSI: ${sig.rsiValue ?: "-"}"
                signalReasons.text = "Reasons:\n" + sig.reasons.joinToString("\n") { "• $it" }
            }
        }
    }

    private fun fmtCountdown(seconds: Int?): String {
        if (seconds == null) return "-"
        val m = seconds / 60
        val s = seconds % 60
        return String.format(Locale.US, "%02d:%02d", m, s)
    }
}
