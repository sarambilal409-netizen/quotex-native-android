package com.quotexsignals.app.data

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * LIVE data adapter that polls an AUTHORIZED REST endpoint YOU supply.
 * Direct port of the original project's adapters/rest_polling_adapter.py.
 * Does not connect to Quotex directly and contains no logic to bypass any
 * platform's login, CAPTCHA, or anti-automation protections.
 *
 * Expected JSON response (GET request, polled every pollSeconds):
 *   {"market":"REAL","asset":"EURUSD","price":1.08421,
 *    "candles":[{"timestamp":"2024-06-01T12:30:00Z","open":1.0841,
 *                "high":1.0845,"low":1.0839,"close":1.0843,
 *                "volume":900,"closed":true}, ...]}
 *
 * Only candles with "closed": true are ever ingested.
 */
class RestPollingAdapter(
    private val url: String,
    private val apiKey: String,
    private val asset: String,
    private val market: String,
    private val pollSeconds: Long = 5,
    private val maxCandles: Int = 500
) : MarketDataAdapter {

    private val client = OkHttpClient()
    private val executor = Executors.newSingleThreadScheduledExecutor()
    private val candles = ConcurrentLinkedDeque<Candle>()
    @Volatile private var currentPrice: Double? = null
    @Volatile private var connected = false

    private val isoFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    override fun connect() {
        executor.scheduleWithFixedDelay({ pollOnce() }, 0, pollSeconds, TimeUnit.SECONDS)
    }

    private fun pollOnce() {
        try {
            val requestBuilder = Request.Builder().url(url)
            if (apiKey.isNotBlank()) requestBuilder.addHeader("Authorization", "Bearer $apiKey")
            client.newCall(requestBuilder.build()).execute().use { resp ->
                if (!resp.isSuccessful) {
                    connected = false
                    return
                }
                val body = resp.body?.string() ?: return
                parseResponse(JSONObject(body))
                connected = true
            }
        } catch (_: Exception) {
            connected = false
        }
    }

    private fun parseResponse(data: JSONObject) {
        if (data.optString("market") != market || data.optString("asset") != asset) {
            return // strict isolation - never mix feeds
        }
        if (data.has("price")) currentPrice = data.optDouble("price")

        val arr = data.optJSONArray("candles") ?: return
        for (i in 0 until arr.length()) {
            val row = arr.optJSONObject(i) ?: continue
            if (!row.optBoolean("closed", false)) continue
            val tsRaw = row.optString("timestamp", "")
            val cleaned = if (tsRaw.endsWith("Z")) tsRaw.dropLast(1) else tsRaw
            val ts = isoFormat.parse(cleaned)?.time ?: continue
            val c = Candle(
                timestampMs = ts,
                open = row.optDouble("open"),
                high = row.optDouble("high"),
                low = row.optDouble("low"),
                close = row.optDouble("close"),
                volume = row.optDouble("volume", 0.0),
                asset = asset,
                market = market
            )
            if (candles.isEmpty() || candles.peekLast().timestampMs < c.timestampMs) {
                candles.addLast(c)
                while (candles.size > maxCandles) candles.removeFirst()
            }
        }
    }

    override fun isConnected(): Boolean = connected
    override fun getMarketType(): String = market
    override fun getAsset(): String = asset
    override fun getCurrentPrice(): Double? = currentPrice
    override fun getClosedCandles(n: Int): List<Candle> = candles.toList().takeLast(n)
    override fun nowMs(): Long = System.currentTimeMillis()

    override fun nextCandleCloseMs(): Long {
        val last = candles.lastOrNull()?.closeTimeMs ?: return System.currentTimeMillis() + Candle.FIVE_MIN_MS
        var next = last
        val now = System.currentTimeMillis()
        while (next <= now) next += Candle.FIVE_MIN_MS
        return next
    }

    override fun getPriceAtOrAfter(tsMs: Long): Double? =
        candles.firstOrNull { it.closeTimeMs >= tsMs }?.close
}
