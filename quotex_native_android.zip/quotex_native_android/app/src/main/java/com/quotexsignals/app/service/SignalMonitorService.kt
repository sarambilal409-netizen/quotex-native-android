package com.quotexsignals.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.quotexsignals.app.MainActivity
import com.quotexsignals.app.R
import com.quotexsignals.app.data.AppConfig
import com.quotexsignals.app.data.AppState
import com.quotexsignals.app.data.Candle
import com.quotexsignals.app.data.DashboardState
import com.quotexsignals.app.data.DemoCsvReplayAdapter
import com.quotexsignals.app.data.MarketDataAdapter
import com.quotexsignals.app.data.RestPollingAdapter
import com.quotexsignals.app.data.SignalDatabase
import com.quotexsignals.app.data.SignalEngine
import com.quotexsignals.app.data.WebSocketAdapter
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Foreground service - the Kotlin equivalent of app.py's background_loop()
 * plus resolve_after_expiry(). Runs a 1-second loop: refreshes live
 * dashboard state, detects newly-CLOSED candles (never re-signals the same
 * candle twice), calls SignalEngine, records actionable signals to SQLite,
 * and resolves each signal's WIN/LOSS/DRAW automatically 5 minutes later
 * using the SAME adapter's actual entry/expiry prices.
 *
 * Shows a persistent notification the whole time it runs, per Android's
 * foreground-service requirements - no hidden background technique is used.
 * See BUILD_README.md for the honest limitations of background operation
 * once Android's own battery/Doze restrictions kick in.
 *
 * This service contains NO code that clicks, submits, or automates any
 * trade, login, or CAPTCHA on Quotex or any other platform.
 */
class SignalMonitorService : Service() {

    private lateinit var adapter: MarketDataAdapter
    private lateinit var db: SignalDatabase
    private lateinit var config: AppConfig
    private var market: String = "OTC"
    private var asset: String = "EURUSD_OTC"
    private var mode: String = "DEMO"

    private val running = AtomicBoolean(false)
    private var loopThread: Thread? = null
    private var lastSignaledCandleCloseMs: Long? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        config = AppConfig(this)
        db = SignalDatabase(this)
        mode = if (config.isDemoMode) "DEMO" else "LIVE"
        market = config.marketType
        asset = config.asset

        adapter = buildAdapter()

        startForeground(NOTIFICATION_ID, buildNotification("Starting..."))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running.compareAndSet(false, true)) {
            try {
                adapter.connect()
            } catch (e: Exception) {
                updateNotification("Failed to start data source: ${e.message}")
                stopSelf()
                return START_NOT_STICKY
            }

            // Hard safety check - refuse to run if the adapter's market type
            // doesn't match configuration, to guarantee REAL/OTC are never mixed.
            if (adapter.getMarketType() != market) {
                updateNotification("Market type mismatch - refusing to start")
                stopSelf()
                return START_NOT_STICKY
            }

            loopThread = Thread { runLoop() }.apply { isDaemon = true; start() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running.set(false)
        super.onDestroy()
    }

    private fun buildAdapter(): MarketDataAdapter = when (config.adapter) {
        AppConfig.ADAPTER_WEBSOCKET -> WebSocketAdapter(
            config.websocketUrl, config.websocketApiKey, asset, market
        )
        AppConfig.ADAPTER_REST -> RestPollingAdapter(
            config.restUrl, config.restApiKey, asset, market
        )
        else -> DemoCsvReplayAdapter(
            this, "sample_otc_5m.csv", asset, market, config.demoSpeed
        )
    }

    private fun clockSpeed(): Double =
        (adapter as? DemoCsvReplayAdapter)?.getSpeed() ?: 1.0

    private fun runLoop() {
        while (running.get()) {
            try {
                tick()
            } catch (e: Exception) {
                // Never crash the service on a transient error (e.g. a live
                // feed hiccup) - just skip this iteration and retry.
            }
            Thread.sleep(1000)
        }
    }

    private fun tick() {
        val candles = adapter.getClosedCandles(200)
        val price = adapter.getCurrentPrice()
        val nextClose = adapter.nextCandleCloseMs()
        val nowSim = adapter.nowMs()
        val rawRemainingMs = (nextClose - nowSim).coerceAtLeast(0)
        val secondsRemaining = (rawRemainingMs / 1000.0 / clockSpeed()).toInt().coerceAtLeast(0)

        var trend: String? = null
        if (candles.size >= 2) {
            trend = com.quotexsignals.app.data.Indicators.trendDirection(
                candles, config.signalConfig().emaFast, config.signalConfig().emaSlow
            )
        }

        AppState.dashboard.postValue(
            DashboardState(
                asset = asset,
                market = market,
                mode = mode,
                connected = adapter.isConnected(),
                currentPrice = price,
                trend = trend,
                nextCandleCloseMs = nextClose,
                secondsRemaining = secondsRemaining,
                latestSignal = AppState.dashboard.value?.latestSignal
            )
        )
        updateNotification(
            if (mode == "DEMO") "DEMO MODE - $asset - next candle in ${secondsRemaining}s"
            else "LIVE - ${if (adapter.isConnected()) "connected" else "not connected"} - $asset"
        )

        if (candles.isNotEmpty()) {
            val lastCloseMs = candles.last().closeTimeMs
            if (lastCloseMs != lastSignaledCandleCloseMs) {
                lastSignaledCandleCloseMs = lastCloseMs
                val result = SignalEngine.generateSignal(candles, config.signalConfig())

                AppState.dashboard.postValue(
                    (AppState.dashboard.value ?: DashboardState()).copy(latestSignal = result)
                )

                if (result.direction == SignalEngine.CALL || result.direction == SignalEngine.PUT) {
                    val entryPrice = candles.last().close
                    val entryTimeMs = lastCloseMs
                    val expiryTimeMs = entryTimeMs + Candle.FIVE_MIN_MS
                    val id = db.recordSignal(
                        asset, market, result.direction, result.confidence,
                        result.reasons, lastCloseMs, entryPrice, entryTimeMs, expiryTimeMs
                    )
                    AppState.notifyHistoryChanged()
                    scheduleResolution(id, expiryTimeMs, result.direction)
                }
            }
        }

        // Fallback: resolve any pending signal whose expiry has already
        // passed on the adapter's own clock (covers service restarts).
        for (row in db.getPending()) {
            if (adapter.nowMs() >= row.expiryTimeMs) {
                resolveNow(row.id, row.expiryTimeMs, row.direction)
            }
        }
    }

    private fun scheduleResolution(signalId: Long, expiryTimeMs: Long, direction: String) {
        Thread {
            val waitSimMs = (expiryTimeMs - adapter.nowMs()).coerceAtLeast(0)
            val waitRealMs = (waitSimMs / clockSpeed()).toLong()
            Thread.sleep(waitRealMs + 1000) // small real-time buffer
            resolveNow(signalId, expiryTimeMs, direction)
        }.apply { isDaemon = true; start() }
    }

    private fun resolveNow(signalId: Long, expiryTimeMs: Long, direction: String) {
        val expiryPrice = adapter.getPriceAtOrAfter(expiryTimeMs)
        db.finalizeResult(signalId, expiryPrice, direction)
        AppState.notifyHistoryChanged()
    }

    // --- Foreground notification plumbing ---

    private fun buildNotification(text: String): Notification {
        val channelId = "signal_monitor_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Signal Monitor", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = android.app.PendingIntent.getActivity(
            this, 0, openIntent,
            android.app.PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Quotex Signal Assistant")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(text))
    }

    companion object {
        private const val NOTIFICATION_ID = 1001
    }
}
