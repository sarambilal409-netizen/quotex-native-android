package com.quotexsignals.app.ui

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.quotexsignals.app.R
import com.quotexsignals.app.data.SignalRow
import java.text.SimpleDateFormat
import java.util.Locale

class HistoryAdapter(private var rows: List<SignalRow>) :
    RecyclerView.Adapter<HistoryAdapter.ViewHolder>() {

    private val dateFmt = SimpleDateFormat("MM/dd HH:mm:ss", Locale.US)

    fun update(newRows: List<SignalRow>) {
        rows = newRows
        notifyDataSetChanged()
    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val time: TextView = view.findViewById(R.id.row_time)
        val direction: TextView = view.findViewById(R.id.row_direction)
        val assetMarket: TextView = view.findViewById(R.id.row_asset_market)
        val prices: TextView = view.findViewById(R.id.row_prices)
        val result: TextView = view.findViewById(R.id.row_result)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_history_row, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val row = rows[position]
        holder.time.text = dateFmt.format(row.entryTimeMs)
        holder.direction.text = row.direction
        holder.direction.setTextColor(
            if (row.direction == "CALL") Color.parseColor("#4fd18b") else Color.parseColor("#ff6b6b")
        )
        holder.assetMarket.text = "${row.asset} (${row.market})  |  Confidence: ${row.confidence}%"
        val expiryStr = row.expiryPrice?.let { String.format(Locale.US, "%.5f", it) } ?: "-"
        holder.prices.text = "Entry: ${String.format(Locale.US, "%.5f", row.entryPrice)}   Expiry: $expiryStr"
        holder.result.text = row.result
        holder.result.setTextColor(
            Color.parseColor(
                when (row.result) {
                    "WIN" -> "#4fd18b"
                    "LOSS" -> "#ff6b6b"
                    "DRAW" -> "#f0c674"
                    "RESULT_UNAVAILABLE" -> "#f0c674"
                    else -> "#8892ab"
                }
            )
        )
    }

    override fun getItemCount(): Int = rows.size
}
