package com.quotexsignals.app.ui

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.quotexsignals.app.R
import com.quotexsignals.app.data.AppConfig
import com.quotexsignals.app.service.SignalMonitorService

/**
 * Settings screen. Lets the user configure Mode (DEMO/LIVE), Market
 * (REAL/OTC), Asset, minimum confidence, and live-feed URL/API key for an
 * authorized data provider. Timeframe is fixed at 5 minutes and not
 * exposed as editable, per the project's requirements.
 *
 * LIVE mode requires a URL to be filled in Settings before it can connect
 * to anything - it never silently claims a Quotex connection.
 */
class SettingsFragment : Fragment(R.layout.fragment_settings) {

    private lateinit var config: AppConfig

    private val modeOptions = listOf("DEMO (bundled CSV, offline)", "LIVE (websocket)", "LIVE (REST polling)")
    private val modeValues = listOf(AppConfig.ADAPTER_DEMO, AppConfig.ADAPTER_WEBSOCKET, AppConfig.ADAPTER_REST)
    private val marketOptions = listOf("OTC", "REAL")

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        config = AppConfig(requireContext())

        val spinnerMode = view.findViewById<Spinner>(R.id.spinner_mode)
        val spinnerMarket = view.findViewById<Spinner>(R.id.spinner_market)
        val editAsset = view.findViewById<EditText>(R.id.edit_asset)
        val editConfidence = view.findViewById<EditText>(R.id.edit_confidence)
        val editWsUrl = view.findViewById<EditText>(R.id.edit_ws_url)
        val editWsKey = view.findViewById<EditText>(R.id.edit_ws_key)
        val editRestUrl = view.findViewById<EditText>(R.id.edit_rest_url)
        val editRestKey = view.findViewById<EditText>(R.id.edit_rest_key)
        val btnSave = view.findViewById<Button>(R.id.btn_save)
        val savedNote = view.findViewById<TextView>(R.id.saved_note)

        spinnerMode.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, modeOptions)
        spinnerMarket.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, marketOptions)

        // Load current values
        spinnerMode.setSelection(modeValues.indexOf(config.adapter).coerceAtLeast(0))
        spinnerMarket.setSelection(marketOptions.indexOf(config.marketType).coerceAtLeast(0))
        editAsset.setText(config.asset)
        editConfidence.setText(config.minConfidence.toInt().toString())
        editWsUrl.setText(config.websocketUrl)
        editWsKey.setText(config.websocketApiKey)
        editRestUrl.setText(config.restUrl)
        editRestKey.setText(config.restApiKey)

        btnSave.setOnClickListener {
            config.adapter = modeValues[spinnerMode.selectedItemPosition]
            config.marketType = marketOptions[spinnerMarket.selectedItemPosition]
            config.asset = editAsset.text.toString().trim().ifBlank { config.asset }
            config.minConfidence = editConfidence.text.toString().toDoubleOrNull() ?: config.minConfidence
            config.websocketUrl = editWsUrl.text.toString().trim()
            config.websocketApiKey = editWsKey.text.toString().trim()
            config.restUrl = editRestUrl.text.toString().trim()
            config.restApiKey = editRestKey.text.toString().trim()

            savedNote.visibility = View.VISIBLE
            restartMonitorService()
        }
    }

    private fun restartMonitorService() {
        val ctx = requireContext()
        ctx.stopService(Intent(ctx, SignalMonitorService::class.java))
        val startIntent = Intent(ctx, SignalMonitorService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(startIntent)
        } else {
            ctx.startService(startIntent)
        }
    }
}
