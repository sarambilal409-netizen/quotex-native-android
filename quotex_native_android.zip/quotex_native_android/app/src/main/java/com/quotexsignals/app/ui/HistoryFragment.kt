package com.quotexsignals.app.ui

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.quotexsignals.app.R
import com.quotexsignals.app.data.AppState
import com.quotexsignals.app.data.SignalDatabase

class HistoryFragment : Fragment(R.layout.fragment_history) {

    private lateinit var db: SignalDatabase
    private lateinit var adapter: HistoryAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        db = SignalDatabase(requireContext())
        adapter = HistoryAdapter(emptyList())

        val list = view.findViewById<RecyclerView>(R.id.history_list)
        list.layoutManager = LinearLayoutManager(requireContext())
        list.adapter = adapter

        refresh()
        // Re-query whenever the monitor service records or resolves a signal.
        AppState.historyChanged.observe(viewLifecycleOwner) { refresh() }
    }

    private fun refresh() {
        adapter.update(db.getHistory(200))
    }
}
