package com.quotexsignals.app.data

import kotlin.math.abs

/**
 * Direct Kotlin port of the original project's core/indicators.py.
 * Operates on ordered lists of CLOSED candles (oldest -> newest) only.
 */
object Indicators {

    /** Exponential moving average over closes, one value per candle. */
    fun ema(values: List<Double>, period: Int): List<Double> {
        if (values.isEmpty()) return emptyList()
        val alpha = 2.0 / (period + 1)
        val out = DoubleArray(values.size)
        out[0] = values[0]
        for (i in 1 until values.size) {
            out[i] = alpha * values[i] + (1 - alpha) * out[i - 1]
        }
        return out.toList()
    }

    /** Wilder-style RSI, one value per candle (first `period` values settle in). */
    fun rsi(values: List<Double>, period: Int = 14): List<Double> {
        if (values.size < 2) return List(values.size) { 50.0 }
        val gains = DoubleArray(values.size)
        val losses = DoubleArray(values.size)
        for (i in 1 until values.size) {
            val delta = values[i] - values[i - 1]
            gains[i] = if (delta > 0) delta else 0.0
            losses[i] = if (delta < 0) -delta else 0.0
        }
        val alpha = 1.0 / period
        val avgGain = DoubleArray(values.size)
        val avgLoss = DoubleArray(values.size)
        avgGain[0] = 0.0
        avgLoss[0] = 0.0
        for (i in 1 until values.size) {
            avgGain[i] = alpha * gains[i] + (1 - alpha) * avgGain[i - 1]
            avgLoss[i] = alpha * losses[i] + (1 - alpha) * avgLoss[i - 1]
        }
        val out = DoubleArray(values.size)
        for (i in values.indices) {
            if (avgLoss[i] == 0.0) {
                out[i] = if (avgGain[i] == 0.0) 50.0 else 100.0
            } else {
                val rs = avgGain[i] / avgLoss[i]
                out[i] = 100 - (100 / (1 + rs))
            }
        }
        return out.toList()
    }

    data class Bollinger(val upper: Double?, val mid: Double?, val lower: Double?)

    /** Bollinger Bands for the LAST candle in `values` only (null if not enough data). */
    fun bollingerLast(values: List<Double>, period: Int = 20, std: Double = 2.0): Bollinger {
        if (values.size < period) return Bollinger(null, null, null)
        val window = values.takeLast(period)
        val mean = window.average()
        val variance = window.sumOf { (it - mean) * (it - mean) } / period
        val sd = kotlin.math.sqrt(variance)
        return Bollinger(mean + std * sd, mean, mean - std * sd)
    }

    /** Average True Range for the LAST candle only. */
    fun atrLast(candles: List<Candle>, period: Int = 14): Double {
        if (candles.size < 2) return 0.0
        val trs = mutableListOf<Double>()
        for (i in 1 until candles.size) {
            val h = candles[i].high
            val l = candles[i].low
            val prevClose = candles[i - 1].close
            val tr = maxOf(h - l, abs(h - prevClose), abs(l - prevClose))
            trs.add(tr)
        }
        val window = trs.takeLast(period)
        // Wilder smoothing approximated with a simple EMA-style average over the window
        val alpha = 1.0 / period
        var value = window.first()
        for (i in 1 until window.size) {
            value = alpha * window[i] + (1 - alpha) * value
        }
        return value
    }

    data class SupportResistance(val support: Double?, val resistance: Double?)

    /** Simple swing-pivot support/resistance from recent closed candles. */
    fun findSupportResistance(candles: List<Candle>, lookback: Int = 20): SupportResistance {
        if (candles.size < 5) return SupportResistance(null, null)
        val window = candles.takeLast(lookback + 2)
        var support: Double? = null
        var resistance: Double? = null
        for (i in 1 until window.size - 1) {
            val h = window[i].high
            val l = window[i].low
            if (window[i - 1].high < h && window[i + 1].high < h) {
                resistance = if (resistance == null) h else maxOf(resistance, h)
            }
            if (window[i - 1].low > l && window[i + 1].low > l) {
                support = if (support == null) l else minOf(support, l)
            }
        }
        return SupportResistance(support, resistance)
    }

    /** Reversal candle patterns detected on the LAST closed candle only. */
    fun detectCandlePattern(candles: List<Candle>): List<String> {
        if (candles.size < 2) return emptyList()
        val last = candles[candles.size - 1]
        val prev = candles[candles.size - 2]
        val patterns = mutableListOf<String>()

        val body = abs(last.close - last.open)
        val range = last.high - last.low
        if (range <= 0) return emptyList()
        val upperWick = last.high - maxOf(last.close, last.open)
        val lowerWick = minOf(last.close, last.open) - last.low

        if (prev.close < prev.open && last.close > last.open &&
            last.close >= prev.open && last.open <= prev.close
        ) {
            patterns.add("Bullish Engulfing")
        }
        if (prev.close > prev.open && last.close < last.open &&
            last.open >= prev.close && last.close <= prev.open
        ) {
            patterns.add("Bearish Engulfing")
        }

        if (body / range < 0.35) {
            if (lowerWick > body * 2 && upperWick < body) {
                patterns.add("Hammer / Bullish Pin Bar")
            }
            if (upperWick > body * 2 && lowerWick < body) {
                patterns.add("Shooting Star / Bearish Pin Bar")
            }
            if (body / range < 0.1) {
                patterns.add("Doji (indecision)")
            }
        }
        return patterns
    }

    /** "UP" / "DOWN" / "SIDEWAYS" based on fast/slow EMA and price position. */
    fun trendDirection(candles: List<Candle>, emaFastP: Int = 9, emaSlowP: Int = 21): String {
        val closes = candles.map { it.close }
        val fastList = ema(closes, emaFastP)
        val slowList = ema(closes, emaSlowP)
        val lastClose = closes.last()
        val fast = fastList.last()
        val slow = slowList.last()
        return when {
            fast > slow && lastClose > fast -> "UP"
            fast < slow && lastClose < fast -> "DOWN"
            else -> "SIDEWAYS"
        }
    }
}
