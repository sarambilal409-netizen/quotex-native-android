package com.quotexsignals.app.data

/**
 * MarketDataAdapter - the contract every data source must implement.
 * Direct port of the original project's adapters/base.py.
 *
 * WHY THIS EXISTS: Quotex does not publish an official, authorized public
 * API for third-party live candle data. This app therefore NEVER connects
 * to Quotex directly, scrapes its app/site, or bypasses its
 * login/CAPTCHA/anti-bot protections. Every part of this system talks to
 * data ONLY through this interface. DemoCsvReplayAdapter (the default,
 * always-available implementation) needs no network at all. WebSocketAdapter
 * and RestPollingAdapter are generic, documented integration points for a
 * feed YOU are authorized to use - see Settings.
 *
 * CONTRACT RULES (enforced by the rest of the app):
 * - marketType must be exactly "REAL" or "OTC" and must never change for a
 *   given adapter instance - AppRepository refuses to mix them.
 * - getClosedCandles() must return ONLY fully closed 5-minute candles,
 *   oldest -> newest. Never the still-forming candle.
 * - getPriceAtOrAfter(ts) is used only for expiry resolution; return null
 *   (never a guess) if a reliable price for that timestamp isn't available.
 */
interface MarketDataAdapter {
    fun connect()
    fun isConnected(): Boolean
    fun getMarketType(): String          // "REAL" or "OTC"
    fun getAsset(): String
    fun getCurrentPrice(): Double?        // display only, never used to generate signals
    fun getClosedCandles(n: Int = 200): List<Candle>
    fun getPriceAtOrAfter(tsMs: Long): Double?
    fun nextCandleCloseMs(): Long
    /** Current adapter clock in epoch ms. Real wall-clock time for live
     *  adapters; an accelerated simulated clock for DemoCsvReplayAdapter. */
    fun nowMs(): Long
}
