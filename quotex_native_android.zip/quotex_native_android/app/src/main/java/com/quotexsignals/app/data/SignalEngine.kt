package com.quotexsignals.app.data

import kotlin.math.abs

/**
 * Direct Kotlin port of the original project's core/signal_engine.py.
 * Combines trend, RSI, Bollinger Bands, support/resistance, candle
 * patterns, recent price action, and an ATR volatility gate into one
 * weighted confluence score. Produces CALL, PUT, or NO_SIGNAL - never
 * forces a pick when evidence is weak or contradictory.
 *
 * IMPORTANT: this class never places a trade. It only returns a
 * SignalResult for display and for AppRepository to record.
 */
object SignalEngine {
    const val CALL = "CALL"
    const val PUT = "PUT"
    const val NO_SIGNAL = "NO SIGNAL"

    // Weights sum to 100, matching the original Python implementation.
    private const val W_TREND = 25
    private const val W_RSI = 15
    private const val W_BOLLINGER = 15
    private const val W_STRUCTURE = 20
    private const val W_PATTERN = 15
    private const val W_PRICE_ACTION = 10

    data class SignalConfig(
        val minConfidence: Double = 65.0,
        val emaFast: Int = 9,
        val emaSlow: Int = 21,
        val rsiPeriod: Int = 14,
        val rsiOversold: Double = 30.0,
        val rsiOverbought: Double = 70.0,
        val bbPeriod: Int = 20,
        val bbStd: Double = 2.0,
        val atrPeriod: Int = 14,
        val minAtrPct: Double = 0.0003,
        val minCandlesRequired: Int = 30,
        val srLookback: Int = 20,
        val srProximityPct: Double = 0.0015
    )

    data class SignalResult(
        val direction: String,
        val confidence: Double,
        val reasons: List<String>,
        val candleTimeMs: Long?,
        val trend: String?,
        val rsiValue: Double?
    )

    private fun recentPriceActionVote(candles: List<Candle>): Pair<Int, String?> {
        if (candles.size < 3) return 0 to null
        val recent = candles.takeLast(3)
        val net = recent.last().close - recent.first().close
        val bullish = recent.count { it.close > it.open }
        val bearish = recent.count { it.close < it.open }
        return when {
            net > 0 && bullish >= 2 -> 1 to "Recent 3-candle price action bullish"
            net < 0 && bearish >= 2 -> -1 to "Recent 3-candle price action bearish"
            else -> 0 to null
        }
    }

    fun generateSignal(candles: List<Candle>, cfg: SignalConfig): SignalResult {
        if (candles.size < cfg.minCandlesRequired) {
            return SignalResult(
                direction = NO_SIGNAL,
                confidence = 0.0,
                reasons = listOf(
                    "Insufficient closed candle history (${candles.size}/${cfg.minCandlesRequired})"
                ),
                candleTimeMs = candles.lastOrNull()?.closeTimeMs,
                trend = null,
                rsiValue = null
            )
        }

        val closes = candles.map { it.close }
        val lastClose = closes.last()
        val reasons = mutableListOf<String>()
        val votes = mutableMapOf<String, Int>()

        // Trend
        val trend = Indicators.trendDirection(candles, cfg.emaFast, cfg.emaSlow)
        votes["trend"] = when (trend) {
            "UP" -> {
                reasons.add("Trend UP (EMA${cfg.emaFast} > EMA${cfg.emaSlow}, price above fast EMA)")
                1
            }
            "DOWN" -> {
                reasons.add("Trend DOWN (EMA${cfg.emaFast} < EMA${cfg.emaSlow}, price below fast EMA)")
                -1
            }
            else -> 0
        }

        // RSI
        val rsiVal = Indicators.rsi(closes, cfg.rsiPeriod).last()
        votes["rsi"] = when {
            rsiVal <= cfg.rsiOversold -> {
                reasons.add("RSI oversold (${"%.1f".format(rsiVal)} <= ${cfg.rsiOversold})")
                1
            }
            rsiVal >= cfg.rsiOverbought -> {
                reasons.add("RSI overbought (${"%.1f".format(rsiVal)} >= ${cfg.rsiOverbought})")
                -1
            }
            else -> 0
        }

        // Bollinger Bands
        val bb = Indicators.bollingerLast(closes, cfg.bbPeriod, cfg.bbStd)
        var bbVote = 0
        if (bb.lower != null && lastClose <= bb.lower && trend != "DOWN") {
            bbVote = 1
            reasons.add("Price at/below lower Bollinger Band (potential bounce)")
        } else if (bb.upper != null && lastClose >= bb.upper && trend != "UP") {
            bbVote = -1
            reasons.add("Price at/above upper Bollinger Band (potential rejection)")
        }
        votes["bollinger"] = bbVote

        // Support / Resistance
        val sr = Indicators.findSupportResistance(candles, cfg.srLookback)
        var srVote = 0
        val prox = cfg.srProximityPct
        if (sr.support != null && abs(lastClose - sr.support) / lastClose <= prox && trend != "DOWN") {
            srVote = 1
            reasons.add("Price near support (${"%.5f".format(sr.support)})")
        } else if (sr.resistance != null && abs(lastClose - sr.resistance) / lastClose <= prox && trend != "UP") {
            srVote = -1
            reasons.add("Price near resistance (${"%.5f".format(sr.resistance)})")
        }
        votes["structure"] = srVote

        // Candle pattern
        val patterns = Indicators.detectCandlePattern(candles)
        var patternVote = 0
        for (p in patterns) {
            if (p.contains("Bullish")) {
                patternVote = 1
                reasons.add("Candle pattern: $p")
            } else if (p.contains("Bearish") || p.contains("Shooting")) {
                patternVote = -1
                reasons.add("Candle pattern: $p")
            }
        }
        votes["pattern"] = patternVote

        // Recent price action
        val (paVote, paReason) = recentPriceActionVote(candles)
        votes["price_action"] = paVote
        paReason?.let { reasons.add(it) }

        // Weighted confluence score
        val weightedSum =
            votes["trend"]!! * W_TREND +
            votes["rsi"]!! * W_RSI +
            votes["bollinger"]!! * W_BOLLINGER +
            votes["structure"]!! * W_STRUCTURE +
            votes["pattern"]!! * W_PATTERN +
            votes["price_action"]!! * W_PRICE_ACTION
        var confidence = abs(weightedSum).toDouble()

        // ATR volatility gate
        val atrVal = Indicators.atrLast(candles, cfg.atrPeriod)
        val atrPct = if (lastClose != 0.0) atrVal / lastClose else 0.0
        if (atrPct < cfg.minAtrPct) {
            confidence *= 0.5
            reasons.add("Low volatility (ATR ${"%.5f".format(atrPct)} < ${cfg.minAtrPct}) - confidence reduced")
        }

        val direction = when {
            weightedSum > 0 -> CALL
            weightedSum < 0 -> PUT
            else -> NO_SIGNAL
        }

        if (direction == NO_SIGNAL || confidence < cfg.minConfidence) {
            return SignalResult(
                direction = NO_SIGNAL,
                confidence = Math.round(confidence * 10) / 10.0,
                reasons = reasons.ifEmpty { listOf("Indicators contradictory or too weak for a confident signal") },
                candleTimeMs = candles.last().closeTimeMs,
                trend = trend,
                rsiValue = Math.round(rsiVal * 10) / 10.0
            )
        }

        return SignalResult(
            direction = direction,
            confidence = Math.round(confidence * 10) / 10.0,
            reasons = reasons,
            candleTimeMs = candles.last().closeTimeMs,
            trend = trend,
            rsiValue = Math.round(rsiVal * 10) / 10.0
        )
    }
}
