package com.quotexsignals.app.data

/**
 * A single CLOSED 5-minute OHLC candle. Ported from the original Python
 * project's core/candle.py. Only closed candles are ever used for
 * indicator/signal calculations - see MarketDataAdapter.getClosedCandles().
 *
 * timestampMs = candle OPEN time, epoch milliseconds (UTC).
 * closeTimeMs is always timestampMs + 5 minutes.
 */
data class Candle(
    val timestampMs: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double = 0.0,
    val asset: String = "",
    val market: String = ""   // "REAL" or "OTC"
) {
    val closeTimeMs: Long get() = timestampMs + FIVE_MIN_MS

    companion object {
        const val FIVE_MIN_MS = 5 * 60 * 1000L
    }
}
