# Quotex Signal Assistant - Standalone Native Android Project

## Status, stated plainly

This is a **complete, standalone Android Studio project**. It is **not**
a compiled `.apk`, and I have **not** built or run it — this sandbox has
no Android SDK and no network access (confirmed directly: no
`gradle`/`sdkmanager` binary exists here, and outbound network requests
return 403). I reviewed every file by hand for the compile errors I could
catch without a compiler (see section "What I found and fixed" below),
but you will be the first person to actually build this.

Once built, the installed app needs **nothing else** to run DEMO mode:
no Termux, no Flask, no Python, no PC, no localhost server, no browser.
Everything - the signal engine, the candle replay, the SQLite database,
the UI - runs natively inside the APK's own process.

---

## Architecture

```
Android APK (single process)
├── MainActivity (native UI, bottom nav host)
│   ├── DashboardFragment   - live price/signal/countdown
│   ├── HistoryFragment     - RecyclerView over SQLite
│   ├── StatisticsFragment  - win/loss/draw stats
│   └── SettingsFragment    - mode/market/asset/confidence/live-feed config
│
├── SignalMonitorService (foreground service, persistent notification)
│   └── 1-second loop: reads adapter -> generates signal -> writes SQLite
│                        -> schedules expiry resolution -> updates LiveData
│
├── data/ (ported analysis logic)
│   ├── Candle, Indicators, SignalEngine     - the "brain"
│   ├── MarketDataAdapter (interface)
│   │   ├── DemoCsvReplayAdapter   - reads bundled assets/sample_otc_5m.csv, ZERO network
│   │   ├── WebSocketAdapter       - authorized live feed only, disabled until configured
│   │   └── RestPollingAdapter     - authorized live feed only, disabled until configured
│   ├── SignalDatabase   - Android SQLiteOpenHelper, append-only signal history
│   └── AppConfig        - SharedPreferences-backed settings
│
└── assets/sample_otc_5m.csv   - bundled demo data, packaged inside the APK
```

No WebView anywhere in this project. No Termux, Flask, or Python anywhere
in this project. `SignalMonitorService` and the UI fragments talk to each
other only through in-process Kotlin objects (`AppState`, `SignalDatabase`)
- there is no HTTP call, no localhost, no port binding of any kind.

---

## J. Files changed / ported from the original project

| Original (Python) | Native Android (Kotlin) | Status |
|---|---|---|
| `core/candle.py` | `data/Candle.kt` | Ported (data class) |
| `core/indicators.py` | `data/Indicators.kt` | Ported - see fidelity note below |
| `core/signal_engine.py` | `data/SignalEngine.kt` | Ported - same weights, same vote logic, same reasons |
| `core/result_tracker.py` | `data/SignalDatabase.kt` | Ported - same schema/semantics, Android's `SQLiteOpenHelper` instead of Python `sqlite3` (no new dependency) |
| `adapters/base.py` | `data/MarketDataAdapter.kt` | Ported (interface) |
| `adapters/csv_replay_adapter.py` | `data/DemoCsvReplayAdapter.kt` | Ported - reads Android `assets/` instead of a filesystem path |
| `adapters/websocket_adapter.py` | `data/WebSocketAdapter.kt` | Ported - OkHttp instead of `websocket-client`, same JSON contract |
| `adapters/rest_polling_adapter.py` | `data/RestPollingAdapter.kt` | Ported - OkHttp instead of `requests`, same JSON contract |
| `app.py` background loop | `service/SignalMonitorService.kt` | Ported - a foreground `Service` thread loop replaces the Flask background thread |
| `app.py` `/api/state` etc + `dashboard.html/js` | `ui/DashboardFragment.kt` + `AppState.kt` | Rewritten as native views + `LiveData` (no HTTP endpoints - same process) |
| `config.yaml` | `data/AppConfig.kt` | Rewritten as `SharedPreferences` (no YAML parser dependency needed) |
| `templates/settings.html` | `ui/SettingsFragment.kt` | Rewritten as a native settings screen |

**Fidelity note on `Indicators.kt`:** RSI and ATR are ported using an
equivalent exponential-smoothing approach, not a byte-identical
reimplementation of pandas' `.ewm()` internals (pandas' handling of the
leading `NaN` in a fresh series, and pandas' Wilder-smoothing seed
behavior, don't have a direct one-line Kotlin equivalent). Signal
direction and confidence should be functionally equivalent, especially
after the 30-candle warm-up period the engine already requires, but
numeric values may differ in the last decimal place from the Python
version. This is the one place where "functionally equivalent" and
"byte-identical" genuinely diverge, and I'd rather flag it than claim
false precision.

The Flask project (`quotex_signal_assistant.zip`) remains the source of
truth and is unmodified by this work - the two are now sibling
implementations of the same logic, not one depending on the other.

---

## What I found and fixed during review

I cannot compile this, so I read every file back through by hand looking
for type errors. I found two real bugs this way:

1. `candles.last.timestampMs` in `WebSocketAdapter.kt` / `RestPollingAdapter.kt`
   - `.last` is not a valid property on `ConcurrentLinkedDeque` in Kotlin
   (it's a function on `Iterable`, not a property, and this class doesn't
   expose one either way). Fixed to `.peekLast()`, the deque's actual API.
2. `AppState.dashboard.postValue(AppState.dashboard.value?.copy(...))` in
   `SignalMonitorService.kt` - passes a nullable `DashboardState?` into a
   `LiveData<DashboardState>` (non-null) `postValue`, a type error. Fixed
   to fall back to a fresh `DashboardState()` before calling `.copy()`.

I'm noting these explicitly because a hand-review is not a substitute for
a real build - there may be others I didn't catch (a missing import, a
resource ID typo). Treat the first real Gradle build as the actual test.

---

## Build steps (exact)

1. Install **Android Studio** (free, https://developer.android.com/studio)
   on a PC. This PC is only needed once, to compile - not to run the app
   afterward.
2. Open Android Studio -> **Open** -> select the `quotex_native_android`
   folder.
3. Let Gradle sync (first sync needs network on your PC to download the
   Android Gradle Plugin, Kotlin plugin, and AndroidX/Material/OkHttp
   dependencies from Google's/Maven's servers - standard for any Android
   project, unrelated to Quotex).
4. **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
5. Output: `app/build/outputs/apk/debug/app-debug.apk`

Equivalent command line (from the project root, with the SDK configured):
```
./gradlew assembleDebug
```
Output path is the same: `app/build/outputs/apk/debug/app-debug.apk`

Filename: `app-debug.apk` · `versionName "1.0"` · `versionCode 1` ·
applicationId `com.quotexsignals.app`.

## Installing

Transfer `app-debug.apk` to your phone (USB/cloud/email) and tap it.
You'll need to allow "install from unknown sources" for whichever app you
use to open the file, since it isn't distributed via Google Play.

## What happens on first launch (intended behavior - please verify)

1. App opens directly to the Dashboard tab.
2. `SignalMonitorService` starts (you'll see a persistent "Quotex Signal
   Assistant" notification - this is the required foreground-service
   notification, not spam; it's how Android requires background work to
   stay visible to the user).
3. `AppConfig` defaults to `adapter = csv_replay`, `market_type = OTC`,
   `asset = EURUSD_OTC` - DEMO mode, automatically, no setup needed.
4. `DemoCsvReplayAdapter` reads `assets/sample_otc_5m.csv` (bundled in
   the APK) and starts replaying it on an accelerated simulated clock -
   zero network calls.
5. Within a few real seconds you should see price/countdown ticking,
   then a CALL/PUT/NO SIGNAL once 30 simulated candles have closed, then
   a WIN/LOSS/DRAW in History once that signal's simulated 5 minutes pass.
6. Force-close and reopen the app: History and Statistics should show the
   same rows as before (SQLite persists to app-private storage
   independent of the process lifecycle).

## Required tests once you have the APK (I could not run these myself)

- Fresh install -> launch -> DEMO MODE badge visible with no setup
- Airplane mode on -> confirm DEMO mode still works fully (it should;
  it makes zero network calls)
- Wait for a signal, then a resolved WIN/LOSS/DRAW
- Rotate the screen mid-countdown - state should persist (no crash, no lost data)
- Force-stop the app from Android settings, reopen - History should still show prior signals
- Restart the phone, reopen the app - History should still show prior signals
- In Settings, switch Market to REAL with Mode still DEMO, save, confirm
  the service restarts cleanly (it will show OTC-labeled demo data mislabeled
  as REAL market internally rejected/ignored - see limitation below)
- Confirm LIVE mode shows "LIVE - NOT CONNECTED" rather than any false
  "connected" claim when no URL is configured

## H. Limitations (honest)

1. **Not built or tested by me** - see status note at the top. This is
   the biggest limitation and I'm not going to understate it.
2. **DemoCsvReplayAdapter's bundled CSV is labeled OTC.** If you set
   Market Type to REAL while staying in DEMO mode, the demo data is still
   OTC-origin data - the adapter will still report `market = "OTC""`
   internally (it's constructed with the market type from config, so
   it'll actually relabel the same synthetic data as "REAL", which is
   informationally meaningless, not a real REAL-market feed). DEMO mode
   is fundamentally an OTC-shaped synthetic dataset; treat Market Type in
   DEMO mode as a UI toggle only, not a claim about the data's real
   origin, until you're on a LIVE adapter with a real feed.
3. **Background operation is bounded by Android's own battery/Doze
   management**, same as any foreground service - a persistent
   notification keeps it running far longer than a background app would
   survive, but very aggressive OEM battery optimizers (some Android
   skins) can still kill it. No hidden workaround was used or attempted.
4. **RSI/ATR numeric fidelity** - see the fidelity note above.
5. **LIVE adapters are generic and unauthenticated to any specific
   provider** - you must supply your own authorized feed's URL/key in
   Settings; nothing here talks to Quotex, and LIVE mode will sit at
   "NOT CONNECTED" until you do.

## G. Adding an authorized live feed later

Same contract as the original Flask project: fill in the Websocket or
REST URL + API key in the Settings screen, pointing at a data source you
are legally authorized to use (a licensed vendor, your broker's own
official API if one exists, or your own compliant middleware). The JSON
message/response schema each adapter expects is documented at the top of
`WebSocketAdapter.kt` and `RestPollingAdapter.kt`. Saving Settings
restarts `SignalMonitorService` so the new adapter takes effect cleanly.
